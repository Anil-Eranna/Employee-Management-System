# program to display records of employee salary - python
# importing packages
import tkinter as tk
import mysql.connector as sql
from tkinter import ttk

#creating functio to fetch data
def fetch_data():
    #connecting to database
    db_connection=sql.connect(host='localhost',database='ems',user='root',password='')
    db_cursor=db_connection.cursor()

    #query
    db_cursor.execute("select * from employee_sal")
    data=db_cursor.fetchall()
    db_connection.close()
    return data

#creating function to display data
def display_data():
    data=fetch_data()

    for row in tree.get_children():
        tree.delete(row)

    #inserting into treeview
    for record in data:
        tree.insert("","end",value=record)

#creating mainwindow
window=tk.Tk()
window.title("Employee Management System")

#creating treeview for displaying data
column=("Ecode","Ename","Dcode","Basic","HRA","PF","Net Salary")
tree=ttk.Treeview(window,column=column,show="headings")

#set up column headings
for col in column:
    tree.heading(col,text=col)

head=ttk.Label(window,text="Employee Salary Details",font="sans 16  bold")
head.grid(row=0,column=0,padx=10,pady=10)

tree.grid(row=1,column=0,padx=10,pady=10)

show_button=ttk.Button(window,text="Show Details",command=display_data)
show_button.grid(row=2,column=0,pady=10)

exit_button=ttk.Button(window,text="Exit",command=window.destroy)
exit_button.grid(row=3,column=0,pady=0)

window.mainloop()
