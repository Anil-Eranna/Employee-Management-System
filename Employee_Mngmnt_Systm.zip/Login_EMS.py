# Login page to open dashboard
import tkinter as tk
import os
import sys
from tkinter import messagebox

#creating function to login
def check_login():

    #getting values from entry box
    username=username_entry.get()
    password=password_entry.get()

    if username=="Admin" and password=="1234":
        window.destroy()
        open_dashboard()
    else:
        messagebox.showerror("Error","Invalid Username And Password")

#def open_main_window():
    #main_window=tk.Tk()
    #main_window.title("Employee Management System")
    #main_window.geometry("400x300")

def open_dashboard():
    import dashboard_ems as o
    #os.system("dashboard_ems.py")
        #main_window.destroy()
        
        

    #lbl=tk.Label(main_window,text="Click here to open Dashboard")
    #lbl.grid(row=0,column=0)

    #btn=tk.Button(main_window,text="Click Here",command=open_dashboard)
    #btn.grid(row=1,column=0)

    #btn2=tk.Button(main_window,text="Cancel",command=main_window.destroy)
    #btn2.grid(row=1,column=1)

    #main_window.mainloop()

#creating login window
window=tk.Tk()
window.title("Employee Management System")
window.geometry("400x300+400+0")

head=tk.Label(window,text="Login Here",font='sans 16 bold',bg='skyblue',fg='black')
head.grid(row=0,columnspan=3,padx=10,pady=10)

username=tk.Label(window,text="Username :",font='sans 14 bold')
username.grid(row=1,column=0)
username_entry=tk.Entry(window,font='sans 14 bold')
username_entry.grid(row=1,column=1,padx=10,pady=10)

password=tk.Label(window,text="Password :",font='sans 14 bold')
password.grid(row=2,column=0)
password_entry=tk.Entry(window,show='*',font='sans 14 bold')
password_entry.grid(row=2,column=1,padx=10,pady=10)

login_button=tk.Button(window,text='Login',font='sans 14 bold',bg='green',fg='black',command=check_login)
login_button.grid(row=3,column=0,padx=10,pady=10)

cancel_button=tk.Button(window,text='Cancel',font='sans 14 bold',fg='red',command=window.destroy)
cancel_button.grid(row=3,column=1,padx=10,pady=10)

window.mainloop()
