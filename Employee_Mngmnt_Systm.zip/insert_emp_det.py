# Creating insert form for Employee Management System
# importing packages
import warnings
warnings.filterwarnings("ignore")

import mysql.connector as sql
import tkinter as tk
from tkinter import *
from tkinter import messagebox

#creating a method to insert data
def insert_details():

    if any([not entry.get() for entry in [Ecode_entry,Ename_entry,Edu_entry,Exp_entry,Dcode_entry]]):
        messagebox.showerror("Error","All fields are mandatory!.")
        return

    #connecting to database
    db_connection=sql.connect(host='localhost',database='EMS',user='root',password='')
    db_cursor=db_connection.cursor()

    #getting data from user
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Edu=Edu_entry.get()
    Exp=Exp_entry.get()
    Dcode=Dcode_entry.get()

    #inserting data into database
    db_cursor.execute("insert into employee_det(Ecode,Ename,Education,Experience,Dcode)values(%s,%s,%s,%s,%s)",[str(Ecode),str(Ename),str(Edu),str(Exp),str(Dcode)])
    messagebox.showinfo("Employee Details","Data Inserted Successfully!")
    #res='Record Added Successfully!'
    #lbl=tk.Label(window,text=res,font='sans 10 bold',bg='skyblue').grid(row=7,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

    db_connection.commit()
    db_connection.close()

    #calling a clear method
    clear_details()
    
def clear_details():
    #clearing Entered data after data inserting
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    Edu_entry.delete(0, tk.END)
    Exp_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)


#creating GUI window
window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x400+260+0")

#creating heading
head=tk.Label(window,width=20,text='Insert Employee Details',font='sans 20 bold',bg='green',fg='white')

Ecode=tk.Label(window,width=15,text='Ecode :',font='sans 18 bold')
Ename=tk.Label(window,width=15,text='Ename :',font='sans 18 bold')
Edu=tk.Label(window,width=15,text='Education :',font='sans 18 bold')
Exp=tk.Label(window,width=15,text='Experience :',font='sans 18 bold')
Dcode=tk.Label(window,width=15,text='Dcode :',font='sans 18 bold')
lbl=tk.Label(window,text='Employee Management System',font='sans 18 bold',bg='skyblue')

Ecode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ename_entry=tk.Entry(window,width=20,font='sans 18 bold')
Edu_entry=tk.Entry(window,width=20,font='sans 18 bold')
Exp_entry=tk.Entry(window,width=20,font='sans 18 bold')
Dcode_entry=tk.Entry(window,width=20,font='sans 18 bold')

#placing controls using grid
head.grid(row=0,column=4,columnspan=8,sticky='nsew',padx=40,pady=10)

Ecode.grid(row=1,column=4,padx=10,pady=4)
Ename.grid(row=2,column=4,padx=10,pady=4)
Edu.grid(row=3,column=4,padx=10,pady=4)
Exp.grid(row=4,column=4,padx=10,pady=4)
Dcode.grid(row=5,column=4,padx=10,pady=4)
lbl.grid(row=7,column=4,columnspan=8,sticky='nsew',padx=10,pady=4)

Ecode_entry.grid(row=1,column=5,padx=10,pady=4)
Ename_entry.grid(row=2,column=5,padx=10,pady=4)
Edu_entry.grid(row=3,column=5,padx=10,pady=4)
Exp_entry.grid(row=4,column=5,padx=10,pady=4)
Dcode_entry.grid(row=5,column=5,padx=10,pady=4)

#creating buttons
submit_button=tk.Button(window,text="Submit",font='ariel 12 bold',width=8,height=2,bg='lightgreen',fg='black',command=insert_details).grid(row=6,column=4,columnspan=5,sticky='w',padx=10,pady=10)
cancel_button=tk.Button(window,text="Cancel",font='ariel 12 bold',width=8,height=2,bg='silver',fg='red',command=window.destroy).grid(row=6,column=5,columnspan=5,sticky='w',padx=10,pady=10)
clear_button=tk.Button(window,text="Clear",font='ariel 12 bold',width=8,height=2,bg='cyan',command=clear_details).grid(row=6,column=6,columnspan=5,sticky='w',padx=10,pady=10)

window.mainloop()
