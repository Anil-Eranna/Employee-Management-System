# program to insert data to a table - python

#importing packages
import tkinter as tk
from tkinter import *
from tkinter import messagebox
import mysql.connector as sql

#creating function to insert details
def insert_details():

    #checking empty value
    if any([not empty.get() for empty in(Ecode_entry,Ename_entry,L_date_entry,Reason_entry,Dcode_entry)]):
        messagebox.showerror("Error","All fields are mandatory")
        return

    #connecting database
    db_connection=sql.connect(host='localhost',database='ems',user='root',password='')
    db_cursor=db_connection.cursor()

    #getting data from entry box
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    L_date=L_date_entry.get()
    Reason=Reason_entry.get()
    Dcode=Dcode_entry.get()

    #query
    db_cursor.execute("insert into leave_det(Ecode,Ename,L_date,Reason,Dcode)values(%s,%s,%s,%s,%s)",[str(Ecode),str(Ename),str(L_date),str(Reason),str(Dcode)])
    messagebox.showinfo("Leave Details","Data Inserted Successfully")
    db_connection.commit()
    
    db_connection.close()
    clear_details()

#creating function to clear details
def clear_details():
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    L_date_entry.delete(0, tk.END)
    Reason_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)
    

#creating mainwindow
window=tk.Tk()
window.title("Employee Management System")
window.geometry("770x500+350+0")


head=tk.Label(window,text="Insert Leave Details",font='sans 18 bold',bg='green',fg='white')
head.grid(row=0,columnspan=3,padx=40,pady=10,sticky='nsew')

Ecode=tk.Label(window,text="Employee Code:",font='sans 18 bold')
Ecode.grid(row=1,column=0,padx=10,pady=4)
Ecode_entry=tk.Entry(window,font='sans 18 bold')
Ecode_entry.grid(row=1,column=1,padx=10,pady=4)

Ename=tk.Label(window,text="Employee Name:",font='sans 18 bold')
Ename.grid(row=2,column=0,padx=10,pady=4)
Ename_entry=tk.Entry(window,font='sans 18 bold')
Ename_entry.grid(row=2,column=1,padx=10,pady=4)

L_date=tk.Label(window,text="Leave Date:",font='sans 18 bold')
L_date.grid(row=3,column=0,padx=10,pady=4)
L_date_entry=tk.Entry(window,font='sans 18 bold')
L_date_entry.grid(row=3,column=1,padx=10,pady=4)

Reason=tk.Label(window,text="Reason",font='sans 18 bold')
Reason.grid(row=4,column=0,padx=10,pady=4)
Reason_entry=tk.Entry(window,font='sans 18 bold')
Reason_entry.grid(row=4,column=1,padx=10,pady=4)

Dcode=tk.Label(window,text="Dcode",font='sans 18 bold')
Dcode.grid(row=5,column=0,padx=10,pady=4)
Dcode_entry=tk.Entry(window,font='sans 18 bold')
Dcode_entry.grid(row=5,column=1,padx=10,pady=4)

insert_button=tk.Button(window,text="Insert",font='ariel 12 bold',width=8,height=2,command=insert_details)
insert_button.grid(row=6,column=0,padx=10,pady=4)

cancel_button=tk.Button(window,text="Cancel",font='ariel 12 bold',width=8,height=2,bg='silver',fg='red',command=window.destroy)
cancel_button.grid(row=6,column=1,pady=10)

lbl=tk.Label(window,text='Employee Management System',font='sans 18 bold',bg='skyblue')
lbl.grid(row=7,column=0,columnspan=8,sticky='nsew',padx=10,pady=4)


window.mainloop()
